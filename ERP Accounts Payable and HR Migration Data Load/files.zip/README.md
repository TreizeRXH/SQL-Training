# ERP Data Migration — End-to-End Practice Project

A fully self-contained ERP data migration exercise covering schema design, staging architecture, data cleansing, validation, and production posting. Built as a realistic simulation of an enterprise migration engagement involving vendor, accounts payable, employee, payroll, and benefits data.

---

## Project Overview

This project simulates a real-world ERP migration from a legacy system to a new SQL Server environment. The source data arrives as a client-delivered Excel workbook — intentionally dirty, incomplete, and inconsistent — and the goal is to cleanse, validate, and post it to a production schema with full auditability.

The exercise covers every phase of a real migration:

| Phase | Description |
|---|---|
| Schema design | Production tables with constraints and referential integrity |
| Staging layer | Mirror tables with all columns nullable for raw import |
| Profiling | Defect scorecard across all six tables |
| Cleansing | Targeted UPDATE statements per defect type |
| Validation | Row-level defect reports and status classification |
| Posting | Type-safe INSERT from staging to production |
| Reconciliation | Source vs target row counts with variance reporting |

---

## Dataset

The source data (`ERP_Migration_Source_Data.xlsx`) is a simulated client-delivered workbook containing **6,550 rows** across six sheets, with intentional dirty data seeded throughout:

| Sheet | Rows | Defect types seeded |
|---|---|---|
| Vendors | 500 | Duplicate names, malformed/missing EINs, mixed phone formats, missing bank details |
| Employees | 1,500 | Missing cost centers, null pay types, no salary or hourly rate, invalid SSNs |
| Benefit Elections | 2,000 | Orphaned elections on inactive employees, missing coverage levels |
| Payroll Records | 2,500 | Invalid pay codes, negative gross pay, net pay reconciliation failures |
| Invoices | 1,000 | Negative amounts, total mismatches, paid invoices missing payment dates |
| Payments | 500 | Negative and zero payment amounts, missing bank accounts |

The workbook also includes:
- A **Data Dictionary** tab defining column requirements, formats, and allowed values
- A **Legend** tab explaining the color-coded data quality indicators (yellow = warning, red = error, green = remediated)

---

## Repository Structure

```
erp-migration/
├── README.md
├── sql/
│   ├── 01_schema_ddl.sql           -- Production schema (ERP_TARGET database)
│   ├── 02_staging_ddl.sql          -- Staging schema (stg_ tables, all nullable)
│   └── 03_validation_and_cleanse.sql -- Full 6-step migration workflow
├── office-scripts/
│   ├── taxid_1_fix_blanks.ts       -- Fix null/blank Tax IDs
│   ├── taxid_2_fix_na.ts           -- Fix N/A Tax IDs
│   ├── taxid_3_fix_pending.ts      -- Fix PENDING Tax IDs
│   ├── taxid_4_fix_missing_dash.ts -- Insert missing dash in 9-digit EINs
│   ├── bankacct_fix_blanks.ts      -- Fill missing bank account numbers
│   ├── routing_fix_blanks.ts       -- Fill missing routing numbers
│   └── routing_validate_checksum.ts -- ABA mod-10 checksum validation
└── docs/
    └── MIGRATION_WORKFLOW.md       -- Step-by-step execution guide
```

---

## SQL Files

### `01_schema_ddl.sql`
Creates the `ERP_TARGET` database and six production tables with full constraints:
- `NOT NULL` enforcement on required fields
- `REFERENCES` foreign key constraints between tables
- Appropriate data types (`DECIMAL` for financial fields, `DATE` for dates, `BIT` for flags)

### `02_staging_ddl.sql`
Creates six `stg_` mirror tables designed to accept raw Excel imports without constraint failures:
- Every column `NVARCHAR` or nullable
- Three migration control columns on every table: `stg_LoadDate`, `stg_Status`, `stg_ErrorNotes`
- `stg_Status` values: `PENDING` → `CLEAN` / `REJECTED`

### `03_validation_and_cleanse.sql`
The core of the exercise. Structured as six sequential steps:

**Step 1 — Defect scorecard**
A single query returning ~35 defect counts across all six tables. This is your baseline report before touching anything.

**Step 2 — Row-level defect reports**
Targeted SELECT statements showing exactly which rows are broken and why, organized by table and defect type.

**Step 3 — Cleanse**
UPDATE statements that fix what can be fixed automatically:
- EIN dash insertion (9-digit → XX-XXXXXXX format)
- Bank account and routing number placeholder fill
- IsActive and StandardHours defaulting
- NetPay recalculation where variance exceeds $1.00
- Invoice TotalAmount recalculation where mismatch exceeds $0.01
- PayCode defaulting to REG where null or invalid (flagged for client review)
- Negative GrossPay classification by pay code (REJECTED vs business review)

Anything requiring business input is stamped `REJECTED` with a plain-English error note in `stg_ErrorNotes`.

**Step 4 — Re-validate**
Re-runs the status summary. Target: no `PENDING` rows remain. All rows are either `CLEAN` or `REJECTED` before proceeding.

**Step 5 — Post to production**
One INSERT per table, selecting only `WHERE stg_Status = 'CLEAN'`, with explicit type casting from `NVARCHAR` staging columns to production data types using `TRY_CAST`.

**Step 6 — Reconciliation**
Compares CLEAN row count in staging against posted row count in production. Every table must show zero variance before sign-off.

---

## Office Scripts (Microsoft 365 / Excel for the Web)

Seven TypeScript Office Scripts for pre-import data cleansing directly in Excel. All scripts share a common pattern:
- Write every change to a `Migration Defect Log` sheet with timestamp, original value, new value, and defect classification
- Use color coding: yellow = flagged/replaced, green = remediated, red = manual review required
- Safe to run independently and in any order — each script skips values handled by the others

### Tax ID (EIN) Scripts — run in order
| Script | What it fixes |
|---|---|
| `taxid_1_fix_blanks.ts` | Null or empty Tax IDs → `99-MIGR####` placeholder |
| `taxid_2_fix_na.ts` | `N/A` Tax IDs → `99-MIGR####` placeholder |
| `taxid_3_fix_pending.ts` | `PENDING` Tax IDs → `99-MIGR####` placeholder |
| `taxid_4_fix_missing_dash.ts` | 9-digit EINs → inserts dash at position 2 (e.g. `123456789` → `12-3456789`). Unknown formats flagged red for manual review. |

### Banking Scripts
| Script | What it fixes |
|---|---|
| `bankacct_fix_blanks.ts` | Missing bank account numbers → `000-MIGR-####` placeholder |
| `routing_fix_blanks.ts` | Missing routing numbers → `999999999` placeholder (clearly invalid, immediately identifiable) |
| `routing_validate_checksum.ts` | Validates existing routing numbers against ABA mod-10 checksum algorithm. Flags failures red. |

---

## Key Concepts Demonstrated

**Staging layer architecture**
Loading raw source data into nullable staging tables before applying constraints prevents import failures and preserves the original data for audit purposes. The staging layer also serves as the defect tracking layer throughout cleansing.

**Explicit type casting**
All financial and date comparisons use `TRY_CAST` rather than relying on implicit conversion. Filtering on raw `NVARCHAR` columns against numeric literals causes implicit INT conversion errors — always cast first.

**Negative value classification by business context**
Not all negative values are errors. Negative invoice amounts may be legitimate credit memos. Negative payroll amounts on BONUS, COMM, REIMB, SEVERANCE, and MISC pay codes may be legitimate clawbacks or reversals. The cleansing logic separates automatic rejections from records requiring business sign-off.

**ABA routing number checksum (mod-10)**
Routing numbers have a built-in validity check: `3(d1+d4+d7) + 7(d2+d5+d8) + 1(d3+d6+d9)` must be divisible by 10. The validation script implements this algorithm to catch routing numbers that would fail downstream payment processing.

**Dummy value strategy**
Placeholder values are chosen to be immediately identifiable as migration artifacts:
- Tax IDs: `99-MIGR####` (99- prefix is not a valid IRS EIN prefix)
- Bank accounts: `000-MIGR-####` (000 prefix is not a valid bank prefix)
- Routing numbers: `999999999` (clearly invalid, stands out in any query or report)

**Defect log as audit trail**
Every automated change is written to a `Migration Defect Log` sheet with the original value, replacement value, defect type, and timestamp — so any downstream question about why a value changed can be answered without relying on memory.

---

## How to Run

1. Run `01_schema_ddl.sql` in SSMS against your SQL Server instance — creates `ERP_TARGET` database and production tables
2. Run `02_staging_ddl.sql` — creates the six `stg_` staging tables
3. Import `ERP_Migration_Source_Data.xlsx` into the staging tables using the SSMS Import and Export Wizard (point each sheet to its corresponding `stg_` table)
4. Run `03_validation_and_cleanse.sql` step by step — Step 1 through Step 6

**Prerequisites**
- SQL Server 2019 or later (Developer or Standard edition)
- SQL Server Management Studio 18+
- Microsoft 365 (for Office Scripts) or Excel desktop with Developer tab enabled (for VBA alternatives)

---

## Skills Demonstrated

`SQL Server` `T-SQL` `ETL` `Data Cleansing` `Data Validation` `Staging Tables` `Window Functions` `TRY_CAST` `TRUNCATE / DELETE` `INSERT...SELECT` `Reconciliation` `TypeScript` `Office Scripts` `Excel Automation` `ERP Migration` `Accounts Payable` `Payroll Data` `Vendor Master` `Data Quality`
